-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j6a102.p.ssafy.io    Database: NFTicket
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `RandomAdjective`
--

DROP TABLE IF EXISTS `RandomAdjective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RandomAdjective` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adjective` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `adjective_UNIQUE` (`adjective`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RandomAdjective`
--

LOCK TABLES `RandomAdjective` WRITE;
/*!40000 ALTER TABLE `RandomAdjective` DISABLE KEYS */;
INSERT INTO `RandomAdjective` VALUES (121,'건조한'),(7,'귀여운'),(2,'기쁜'),(120,'눅눅한'),(123,'달리는'),(5,'달콤한'),(109,'두꺼운'),(107,'따뜻한'),(117,'똑똑한'),(108,'뜨거운'),(118,'매콤한'),(122,'빛나는'),(6,'상큼한'),(111,'새까만'),(113,'새빨간'),(127,'새콤한'),(114,'새파란'),(110,'새하얀'),(112,'샛노란'),(126,'설레는'),(3,'슬픈'),(106,'시원한'),(124,'엄숙한'),(9,'예쁜'),(8,'잘생긴'),(125,'정중한'),(1,'즐거운'),(119,'지독한'),(4,'짜릿한'),(128,'차가운'),(115,'푸릇한'),(116,'풋풋한');
/*!40000 ALTER TABLE `RandomAdjective` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-07 10:46:55
