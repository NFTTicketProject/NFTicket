-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j6a102.p.ssafy.io    Database: NFTicket
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `RandomNoun`
--

DROP TABLE IF EXISTS `RandomNoun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RandomNoun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `noun` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `noun_UNIQUE` (`noun`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RandomNoun`
--

LOCK TABLES `RandomNoun` WRITE;
/*!40000 ALTER TABLE `RandomNoun` DISABLE KEYS */;
INSERT INTO `RandomNoun` VALUES (42,'갈비탕'),(44,'감자떡'),(43,'감자탕'),(24,'개'),(46,'개복치'),(33,'고등어'),(35,'고래'),(45,'고슴도치'),(23,'고양이'),(3,'곰'),(29,'광어'),(25,'금붕어'),(49,'기차'),(4,'낙타'),(40,'농어'),(2,'늑대'),(18,'당나귀'),(15,'돼지'),(41,'떡볶이'),(17,'말'),(34,'망둥어'),(38,'방어'),(47,'버스'),(39,'빙어'),(7,'사슴'),(1,'사자'),(36,'상어'),(16,'소'),(31,'송어'),(21,'수탉'),(22,'암탉'),(28,'앵무새'),(20,'양'),(8,'얼룩말'),(13,'여우'),(30,'연어'),(19,'염소'),(6,'원숭이'),(32,'전어'),(48,'지하철'),(37,'철갑상어'),(11,'캥거루'),(10,'코끼리'),(12,'코알라'),(50,'택시'),(26,'토끼'),(14,'판다'),(5,'표범'),(27,'햄스터'),(9,'호랑이');
/*!40000 ALTER TABLE `RandomNoun` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-07 10:46:54
